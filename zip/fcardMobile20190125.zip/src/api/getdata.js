import request from '../utils/axios';
// console.log(request)
function setparam(data){
    var parmass1 = new URLSearchParams()
    for (var i in data) {
        parmass1.append(i, data[i]);
    }
    console.log(parmass1)
    return parmass1
}


export function RecentAccessRecord(param) {//获取操作员列表
    return request({
        url: 'WebAPI/PersonalReport/RecentAccessRecord',
        method: 'post',
        data:setparam(param)
    })
}

export function EnterAccessRecord(param) {//进门记录
    return request({
        url: '/WebAPI/PersonalReport/EnterAccessRecord',
        method: 'post',
        data:setparam(param)
    })
}
export function OutAccessRecord(param) {//出门记录
    return request({
        url: '/WebAPI/PersonalReport/OutAccessRecord',
        method: 'post',
        data:setparam(param)
    })
}
export function AlarmRecord(param) {//报警记录
    return request({
        url: '/WebAPI/PersonalReport/AlarmRecord',
        method: 'post',
        data:setparam(param)
    })
}
export function ConferencePeopleRecord(param) {//参会迟到记录
    return request({
        url: '/WebAPI/PersonalReport/ConferencePeopleLateRecord',//参会迟到记录
        method: 'post',
        data:setparam(param)
    })
}
export function ConferencePeopleAbsenceRecord(param) {//参会缺席记录
    return request({
        url: '/WebAPI/PersonalReport/ConferencePeopleAbsenceRecord', //参会缺席记录
        method: 'post',
        data:setparam(param)
    })
}
export function ConferencePeopleLateRecord(param) {//参会迟到
    return request({
        url: '/WebAPI/PersonalReport/ConferencePeopleLateRecord', //参会迟到
        method: 'post',
        data:setparam(param)
    })
}
export function ConferencePeopleLeaveRecord(param) {//参会请假记录
    return request({
        url: '/WebAPI/PersonalReport/ConferencePeopleLeaveRecord', //参会请假记录
        method: 'post',
        data:setparam(param)
    })
}

export function POSReservationRecord(param) {//订餐记录
    return request({
        url: '/WebAPI/PersonalReport/POSReservationRecord', //订餐记录
        method: 'post',
        data:setparam(param)
    })
}


export function RecentPOSTransactionRecord(param) {//最近消费记录
    return request({
        url: '/WebAPI/PersonalReport/RecentPOSTransactionRecord',//最近消费记录
        method: 'post',
        data:setparam(param)
    })
}


export function POSTransactionRecord(param) {//消费记录
    return request({
        url: '/WebAPI/PersonalReport/POSTransactionRecord', //消费记录
        method: 'post',
        data:setparam(param)
    })
}


export function POSTransactionRechargeRecord(param) {//充值记录
    return request({
        url: '/WebAPI/PersonalReport/POSTransactionRechargeRecord', //充值记录
        method: 'post',
        data:setparam(param)
    })
}

export function POSUserDestroyCardRecord(param) {//销户记录
    return request({
        url: '/WebAPI/PersonalReport/POSUserDestroyCardRecord', //销户记录
        method: 'post',
        data:setparam(param)
    })
}
export function WithdrawalPOSUserChangeCardRecord(param) {//取款记录
    return request({
        url: '/WebAPI/PersonalReport/WithdrawalPOSUserChangeCardRecord', //取款记录
        method: 'post',
        data:setparam(param)
    })
}

export function POSUserChangeCardRecord(param) {//换卡记录
    return request({
        url: '/WebAPI/PersonalReport/POSUserChangeCardRecord', //换卡记录
        method: 'post',
        data:setparam(param)
    })
}

export function RecentWaterTransactionRecord(param) {//最近水控消费记录
    return request({
        url: '/WebAPI/PersonalReport/RecentWaterTransactionRecord', //最近水控消费记录
        method: 'post',
        data:setparam(param)
    })
}

export function WaterTransactionRecord(param) {//水控消费记录
    return request({
        url: '/WebAPI/PersonalReport/WaterTransactionRecord', //水控消费记录
        method: 'post',
        data:setparam(param)
    })
}
