<template>
  <div class="home">
    <mu-appbar style="width: 100%;" color="primary">
      <mu-button icon slot="left">
        <!-- <mu-icon value="menu"></mu-icon> -->
      </mu-button>欢迎使用系统
      <!-- <mu-button flat slot="right"> -->
      <mu-badge content="1" circle color="secondary" flat slot="right" class="right">
        <mu-button icon class="asdf" @click="Inform">
          <mu-icon value="notifications" class="asf"></mu-icon>
        </mu-button>
      </mu-badge>
      <!-- </mu-button> -->
    </mu-appbar>
    <div class="warp">
      <mu-row justify-content="center">
        <mu-avatar :size="100">
          <img src="https://muse-ui.org/img/uicon.ac3913bf.jpg">
        </mu-avatar>
      </mu-row>
      <mu-row justify-content="center">欢迎你 fcard</mu-row>
      <!-- <mu-row justify-content="center">time:{{new Date().toLocaleTimeString()}}</mu-row> -->
      <!-- <mu-list :ripple='true' class="list_ul">
        <mu-list-item button >
          <mu-list-item-title>最近出门记录</mu-list-item-title>
          <mu-list-item-action>
            <mu-icon value="keyboard_arrow_right"></mu-icon>
          </mu-list-item-action>
        </mu-list-item>
        <mu-divider></mu-divider>
        <mu-list-item button >
          <mu-list-item-title>最近入门记录</mu-list-item-title>
          <mu-list-item-action>
            <mu-icon value="keyboard_arrow_right"></mu-icon>
          </mu-list-item-action>
        </mu-list-item>
        <mu-divider></mu-divider>
        <mu-list-item button >
          <mu-list-item-title>最近入门记录</mu-list-item-title>
          <mu-list-item-action>
            <mu-icon value="keyboard_arrow_right"></mu-icon>
          </mu-list-item-action>
        </mu-list-item>
        <mu-divider></mu-divider>
        <mu-list-item button >
          <mu-list-item-title>最近入门记录</mu-list-item-title>
          <mu-list-item-action>
            <mu-icon value="keyboard_arrow_right"></mu-icon>
          </mu-list-item-action>
        </mu-list-item>
        <mu-divider></mu-divider>
        <mu-list-item button >
          <mu-list-item-title>最近入门记录</mu-list-item-title>
          <mu-list-item-action>
            <mu-icon value="keyboard_arrow_right"></mu-icon>
          </mu-list-item-action>
        </mu-list-item>
        <mu-divider></mu-divider>
        <mu-list-item button >
          <mu-list-item-title>最近入门记录</mu-list-item-title>
          <mu-list-item-action>
            <mu-icon value="keyboard_arrow_right"></mu-icon>
          </mu-list-item-action>
        </mu-list-item>
        <mu-divider></mu-divider>
        <mu-list-item button >
          <mu-list-item-title>xxxxxxxxxxxx</mu-list-item-title>
          <mu-list-item-action>
            <mu-icon value="keyboard_arrow_right"></mu-icon>
          </mu-list-item-action>
        </mu-list-item>
      </mu-list> -->
      <div class="list_ul">
        <div class="warp_tit" >最近出入门记录</div>
        <Table
          :data="list"
          border
          @row-click="rowClick"
          ref="table_data"
          :height='"calc(100% - 1.04rem)"' 
          size='mini'
          style="width: 100%;">
          {{list}}
          <table-column prop="DoorName" label="门名称" width></table-column>
          <table-column align="" prop="DataTime" label="时间" width='160'></table-column>
          <table-column prop="PortNum" label="事件类型" width='80'>
              <!-- <template scope="scope"> -->
                <!-- {{scope}} -->
              <!-- </template> -->
              <!-- {{PortNum}} -->
              <template slot-scope="scope">
               
                  {{scope.row.PortNum==1?'入门':'出门'}}
                
              </template>
          </table-column>
        </Table>
      </div>
    </div>
    <mu-bottom-nav class="nav">
      <mu-bottom-nav-item title="个人中心" icon="person_pin" @click.native="toPerson"></mu-bottom-nav-item>
      <mu-bottom-nav-item title="报表查询" icon="table_chart" @click.native="toReport"></mu-bottom-nav-item>
    </mu-bottom-nav>
    
  </div>
</template>
<script>

import { Table, TableColumn } from "element-ui";
import {RecentAccessRecord} from '@/api/getdata'
export default {
  name: "index",
  data() {
    return {
      list: [],
    };
  },
  components:{
    Table, TableColumn
  },
  created() {
    let that=this
    
  },
  mounted() {
    let that=this
    RecentAccessRecord().then(res=>{
      // console.log(res.RetData);
      that.list=[...res.RetData.Data];
      console.log(that.list)
    }).catch(err=>{
      // alert(err)
    })
  },
  methods:{
    handleSortChange() {
      console.log(data);
    },
    rowClick(data) {
      console.log(data);
    },
    toPerson(){
      // alert();
      let that=this;
      this.$progress.start();
      setTimeout(() => {
        that.$progress.done();
        that.$router.push({path:'personal'});
        that.$store.state.transitionName='slide-left'
      }, 300);
      
    },
    toReport(){
      let that=this;
      this.$progress.start();
      setTimeout(() => {
        that.$progress.done();
        that.$router.push({path:'Report'});
        that.$store.state.transitionName='slide-left'
      }, 300);
    }
    ,
    Inform(){//通知
      alert('管理员通知信息');
    }
  }
};
</script>
<style lang="scss" scoped>
.home {
  width: 100%;
  height: 100%;
}
.right {
  display: inline;
  .asdf {
    color: #fefedd;
  }
}
.nav {
  position: fixed;
  bottom: 0;
  width: 100%;
}
.warp{
  margin-top: 8px;
  height: calc( 100% - 64px);
    min-height: 6.9333rem;
    padding-bottom: 56px;
}
.list_ul{
  height: calc( 100% - 118px );
  overflow-y: auto;
  .warp_tit{
    font-size: 0.5333rem;
    font-weight: 600;
    padding: 0.1333rem 0;
  }
  .el-table--mini{
    font-size: 0.32rem;
  }
}
</style>
<style>
em.mu-badge-float {
  position: absolute;
  top: 2px;
  right: -1px;
}
</style>


