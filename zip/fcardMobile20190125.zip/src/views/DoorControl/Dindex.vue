<template>
  <div class="home">
    <Nav :title="$route.query.item"></Nav>
    <div class="wrap" ref='loadmore'>
      <!-- {{}} -->
      <Table
          border
          size='mini'
          ref="table_data"
          style="width: 100%;position:fixed;z-index:50;" :height='36'
        >
          <table-column  label="门名称" width='90'></table-column>
          <table-column  label="日期" width></table-column>
          <table-column  label="状态" width='60'></table-column>
        </Table>
      <mu-load-more @refresh="refresh" :refreshing="refreshing" :loading="loading">
        <Table
          :data="list"
          border
          @row-click="rowClick" size='mini'
          ref="table_data1"
          style="width: 100%;">
          <table-column prop="DoorName" width='90'></table-column>
          <table-column align="" prop="DataTime" width></table-column>
          <table-column width='60'>
              <template slot-scope="scope">
                  {{scope.row.PortNum==1?'出门':'入门'}}
              </template>
          </table-column>
        </Table>
      </mu-load-more>
    </div>
    <mu-drawer style="width:7.4667rem" :open.sync="open" :docked="false" right="right">
      <mu-appbar style="width: 100%;" title="搜索" color="teal"></mu-appbar>
      <mu-row justify-content="center" class="mu-person-form">
        <mu-form ref="form" :model="form" label-width="86">
          <mu-form-item label-position="right" label="姓名:">
            <mu-text-field v-model="form.name"></mu-text-field>
          </mu-form-item>
          <mu-form-item label-position="right" label="搜索条件:">
            <mu-text-field v-model="form.data1"></mu-text-field>
          </mu-form-item>

          <mu-form-item label-position="right" label="搜索条件:">
            <mu-text-field type="password" v-model="form.data2"></mu-text-field>
          </mu-form-item>

         <mu-button color="primary" @click="submit" class="submit">搜索</mu-button>
          <!-- <div class="submit"> -->
            
          <!-- </div> -->
        </mu-form>
      </mu-row>
    </mu-drawer>
    <mu-dialog width="360" :open.sync="openSimple">
      <mu-list>
        <mu-list-item button :ripple="false" v-for='(item,index) in rowdata' :key="index">
          
            {{item}}78789
        </mu-list-item>
      </mu-list>
    </mu-dialog>
  </div>
</template>
<script>
import Nav from "@/components/nav_top";
import { Table, TableColumn } from "element-ui";
import {RecentAccessRecord} from '@/api/getdata'
export default {
  components: {
    Nav,
    Table,
    TableColumn
  },
  data() {
    return {
      open: false,
      refreshing: false,
      loading: false,
      openSimple:false,
      list: [],
      rowdata:'',
      form: {
        name: "name",
        data1: "123",
        data2: "123123"
      },
      pagesize:30,
      pageindex:1
    };
  },
  mounted() {
    
    this.getdata()
  },
  methods: {
    openD() {
      //打开侧边
      this.open = true;
    },
    handleSortChange() {
      console.log(data);
    },
    rowClick(data) {
      console.log(data);
      this.openSimple=true;
      this.rowdata=data;
      [this.rowdata].map((item)=>{
        console.log(item);
        
      })
    },
    getdata(){
        let that=this;
        RecentAccessRecord({PageIndex:this.pageindex,PageSize:this.pagesize}).then(res=>{
        // console.log(res.RetData);
        that.list=[...that.list,...res.RetData.Data];
        console.log(that.list)
        }).catch(err=>{
        // alert(err)
        })
    },
    refresh() {
      
      this.refreshing = true;
      this.$refs.table_data.scrollTop = 0;
      setTimeout(() => {
        this.refreshing = false;
        this.list=[];
        this.getdata()
      }, 2000);
    },
    load() {
      this.loading = true;
      this.pageindex++;
      let a=this.$refs.loadmore.scrollTop;
      console.log(5555555)
      this.$refs.loadmore.scrollTop=a
    //   this.getdata()
    let that=this;
      RecentAccessRecord({PageIndex:this.pageindex,PageSize:this.pagesize}).then(res=>{
        // console.log(res.RetData);
        
        
        that.list=[...that.list,...res.RetData.Data];
        setTimeout(() => {
            that.$refs.loadmore.scrollTop=a
        }, 500);
        setTimeout(()=>{
            that.loading = false;
            
        },1000)
        console.log(that.list)
        }).catch(err=>{
        // alert(err)
        that.loading = false;
        })
    },
    submit(){

    }
  }
};
</script>
<style>
.home {
  height: 100%;
}
.wrap {
  position:relative;
  height: calc(100% - 60px);
  margin-top: 0.1067rem;
  overflow: auto;
}
</style>


