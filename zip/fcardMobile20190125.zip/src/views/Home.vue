<template>
    <div class="home">
      
      <mu-container>
        <div class="title">欢迎登陆</div>
        <mu-form ref="form" :model="validateForm" class="mu-demo-form" label-width='100'>
          <mu-form-item label-position='right' label="套账">
            <mu-text-field v-model="validateForm.username"></mu-text-field>
          </mu-form-item>
          <mu-form-item label="身份类型" label-position='right'>
            <!-- <mu-select  v-model="people" full-width @change="setPeople" ripple='true' > -->
              <!-- <mu-option v-for="(city,index) in arrpeople" :key="index" :label="city" :value="city"></mu-option> -->
              <mu-radio v-model="people" style="margin-right: 16px;" value="管理员" label="管理员"></mu-radio>
              <mu-radio v-model="people" style="margin-right: 16px;" value="个人" label="个人"></mu-radio>
            <!-- </mu-select> -->
          </mu-form-item>
          <mu-form-item label-position='right' label="管理员名称：" v-if='people=="管理员" '>
              <mu-text-field type="password" v-model="validateForm.password"></mu-text-field>
          </mu-form-item>
          <mu-form-item label-position='right' label="密码：" v-if='people=="管理员" '>
              <mu-text-field type="password" v-model="validateForm.password"></mu-text-field>
          </mu-form-item>

          <mu-form-item label-position='right' label="身份类别" v-if='people=="个人" '>
              <!-- <mu-select  v-model="item" full-width @change="setItem" ripple=true >
                <mu-option v-for="(city,index) in ['身份证','卡号']" :key="index" :label="city" :value="city"></mu-option>
              </mu-select> -->
              <mu-radio v-model="item" style="margin-right: 16px;" value="身份证" label="身份证"></mu-radio>
              <mu-radio v-model="item" style="margin-right: 16px;" value="卡号" label="卡号"></mu-radio>
          </mu-form-item>
          <mu-form-item label-position='right' label="身份证号码：" v-if='people=="个人"&& item =="身份证"'>
              <mu-text-field type="password" v-model="validateForm.password"></mu-text-field>
          </mu-form-item>
           <mu-form-item label-position='right' label="卡号：" v-if='people=="个人"&& item =="卡号"'>
              <mu-text-field type="password" v-model="validateForm.password"></mu-text-field>
          </mu-form-item>
          <div class="submit">
            <mu-button color="primary" @click="submit">提交</mu-button>
            <mu-button @click="clear">重置</mu-button>
          </div>
        </mu-form>
      </mu-container>
    </div>
</template>


<script>
import axios from 'axios'
import {GetUserList} from './../api/getdata.js'
export default {
  name:'home',
  data () {
    return {
      usernameRules: [
        { validate: (val) => !!val, message: '必须填写用户名'},
        { validate: (val) => val.length >= 3, message: '用户名长度大于3'}
      ],
      validateForm: {
        username: '',
        password: '',
        isAgree: false
      },
      people:'管理员',
      // arrpeople:['管理员','个人'],
      item:'身份证'
    }
  },
  mounted() {
    // console.log(GetUserList,'+++++++++++++++++++++')
    // GetUserList().then(res=>{
    //   console.log(res)
    // })
  },
  methods: {
    setPeople( value ){ 
      this.people=value;
    },
    setItem(value){
      this.item=value;
    },
   submit(){
     console.log(this.$router.path)
     this.$router.push({path:'Index'})
   },
    clear () {
      this.$refs.form.clear();
      this.validateForm = {
        username: '',
        password: '',
        isAgree: false
      };
    }
  }
};
</script>
<style lang="scss" scoped>
.home{
  width: 95%;
  height: 100%;
  box-sizing: border-box;
  margin: auto;
  position: relative;
  .container{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    .title{
      font-size: 20px;
      font-weight: 600;
    }
  }
  .submit{
    text-align: center;
    button{
      margin: 0 5px;
    }
  }
}
.mu-form-item-content{
  justify-content:space-around;
}
.mu-demo-form {
  width: 100%;
  max-width: 460px;
}
.container form{
  margin: auto;
}
</style>