<template>
  <div id="app">
    <!-- <keep-alive> -->
      <transition :name="$store.state.transitionName">   
        <router-view></router-view>
      </transition>
      <!-- <router-view/> -->
    <!-- </keep-alive> -->
  </div>
</template>
<script>
export default {
  mounted() {
    let that=this;
    window.addEventListener("popstate", function(e) {
      // alert()
      console.log(that.$store);
      that.$store.state.transitionName='slide-right'
    }, false);
  },  
}
</script>

<style>
html,body{
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.home{
  width: 100%;
}
#app {
  width: 100%;
  height: 100%;
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin: 0;
  /* margin-top: 60px; */
}

/* 页面切换动画 */
.slide-right-enter-active,
.slide-right-leave-active,
.slide-left-enter-active,
.slide-left-leave-active {
  will-change: transform;
  transition: all 500ms;
  position: absolute;
}
.slide-right-enter {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}
.slide-right-leave-active {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.slide-left-enter {
  opacity: 0;
  transform: translate3d(100%, 0, 0);
}
.slide-left-leave-active {
  opacity: 0;
  transform: translate3d(-100%, 0, 0);
}
</style>
