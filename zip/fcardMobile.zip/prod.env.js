'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_ROOT:'http://127.0.0.1:802'
}
