import Vue from 'vue'
import App from './App.vue'
import store from './store'
import router from './router'
//
import MuseUI from 'muse-ui';
import 'muse-ui/dist/muse-ui.css';
Vue.use(MuseUI);
//
import 'font-awesome/css/font-awesome.min.css'
import 'material-design-icons-iconfont/dist/material-design-icons.css'
import 'lib-flexible/flexible.js'
import {
  axios
} from './js/axios'


// 页面加载进度
import 'muse-ui-progress/dist/muse-ui-progress.css';
import NProgress from 'muse-ui-progress';
Vue.use(NProgress);

import "element-ui/lib/theme-chalk/index.css";
import { Table, TableColumn,Tabs, TabPane } from 'element-ui';

Vue.use(Table)
Vue.use(TableColumn)
Vue.use(Tabs)
Vue.use(TabPane)

import Toast from 'muse-ui-toast';

Vue.use(Toast);

import dateTime from 'vue-date-time-m';

Vue.use(dateTime);
// 个人写的组件
// import Nav from './components/nav_top.vue'

Vue.config.productionTip = false

// Vue.component('Nav',Nav);
NProgress.start(); //加载条
NProgress.done();
NProgress.config({
  color: 'secondary', // color
  size: 2
});




new Vue({
  store,
  router,
  render: h => h(App)
}).$mount('#app')