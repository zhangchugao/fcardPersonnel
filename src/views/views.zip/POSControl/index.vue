<template>
<!-- 缺席记录 -->
  <div class="home">
    <Nav icon="search" @openDialog="openD" :title="'在线订餐'"></Nav>
    <div class="wrap" ref="loadmore">
      <Table
        border
        @row-click="rowClick"
        size="mini"
        ref="table_data"
        style="width: 100%;position:fixed;z-index:50;"
        :height="36">
        <table-column label="姓名"></table-column>
        <table-column label="编号"></table-column>
        <table-column label="部门"></table-column>
      </Table>
      <mu-load-more @refresh="refresh" :refreshing="refreshing" :loading="loading" @load="load" :loaded-all='loadedAll'>
        <Table :data="list" border @row-click="rowClick" size="mini" ref="table_data1" style="width: 100%;" @selection-change="tableSelectChange">
          <el-table-column type="selection" width="40" align="center"></el-table-column>
          <table-column prop="PName" label="姓名"></table-column>
          <table-column prop="PCode" label="编号"></table-column>
          <table-column prop="DeptName" label="部门"> </table-column>
        </Table>
      </mu-load-more>
    </div>
    <mu-button color="primary" @click="bookking">在线订餐</mu-button>
    <mu-drawer style="width:7.4667rem" :open.sync="open" :docked="false" right="right">
      <mu-appbar style="width: 100%;" title="搜索" color="teal"></mu-appbar>
      <mu-row justify-content="center" class="mu-person-form">
        <mu-form ref="form" :model="searchitem" label-width="80">
          <mu-form-item label-position="right" label="姓名:">
            <mu-text-field v-model="searchitem.PName"></mu-text-field>
          </mu-form-item>
            <mu-form-item label-position="right" label="部门:">
               <mu-text-field v-model="searchitem.DeptName"></mu-text-field>
          </mu-form-item>
            <mu-form-item label-position="right" label="编号:">
              <mu-text-field v-model="searchitem.PCode"></mu-text-field>
          </mu-form-item>
          <mu-button color="primary" @click.native="submit" class="submit">搜索</mu-button>
        </mu-form>
      </mu-row>
    </mu-drawer>
    <!-- 选择订餐餐段 -->
    <mu-dialog width="360" transition="slide-right" fullscreen :open.sync="openSync">
        <mu-appbar color="primary" title="选择订餐时段">
            <mu-button slot="left" icon @click="closeFullscreenDialog">
                <mu-icon value="close"></mu-icon>
            </mu-button>
            <mu-button slot="right" flat  @click="nextStep">
                下一步
            </mu-button>
        </mu-appbar>
        <div style="padding: 24px;">
            <Table
            :data="MIMIList"
            border
            @selection-change="MIMIListSelectChange"
            size="mini"
            ref="table_data"
            style="width:100%"
            >
                <el-table-column type="selection" width="40" align="center"></el-table-column>
                <table-column label="名称" prop="MName"></table-column>
                <table-column label="订餐时间" prop="tiem"></table-column>
                <table-column label="可提前">
                    <template slot-scope="scope">
                        {{ scope.row.AdvanceDay }} 天
                    </template>
                </table-column>
            </Table>
        </div>
        <!-- <mu-button color="primary" @click="nextStep">下一步</mu-button> -->
    </mu-dialog>
    <!-- 订餐详细信息 -->
    <mu-dialog width="360" transition="slide-right" fullscreen :open.sync="openSyncInfo">
        <mu-appbar color="primary" title="订餐详情">
            <mu-button slot="left" icon @click="openSyncInfo=false">
                <mu-icon value="close"></mu-icon>
            </mu-button>
        </mu-appbar>
       <mu-form ref="form" :model="form" label-width="80">
          <mu-form-item label-position="right" label="订餐餐段:">
            <mu-select label="" v-model="form.FixedFeeRuleID" full-width>
              <mu-option v-for="(option,index) in BoodingList" :key="index" :label="option.RuleName" :value="option.FixedFeeRuleID"></mu-option>
            </mu-select>
          </mu-form-item>
         <mu-form-item label-position="right" label="订餐日期:">
             <mu-date-input v-model="form.ReservationDate" label="选择日期" label-float full-width container='bottomSheet' :min-date="new Date()"></mu-date-input>
          </mu-form-item>
        <mu-form-item label-position="right" label="备注:">
            <mu-text-field multi-line :rows="3" :rows-max="6" v-model="form.Remark"></mu-text-field>
        </mu-form-item>
       </mu-form>
       <mu-button color="primary" @click="Book">订餐</mu-button>
    </mu-dialog>
  </div>
</template>
<script>
import Nav from "@/components/nav_top_menu";
import { Table, TableColumn } from "element-ui";
import { ConferencePeopleAbsenceRecord, PeosonalPosGetAllPeople, DepartmentGetDepartmentList, PeosonalPosGetPOSMealTime, PeosonalPosGetFixedFeeRule, PeosonalPosReservationInsert } from "@/api/getdata";
import { parseTime } from '@/utils/index'
import moment from 'moment'
export default {
  components: {
    Nav,
    Table,
    TableColumn
  },
  data() {
    return {
      open: false,
      openSyncInfo: false,
      BoodingList: [],
      refreshing: false,
      loading: false,
      openSimple: false,
      list: [],
      MIMIList: [],
      rowdata: "",
      MIMIselections: [],
      searchitem:{
        PName: '',
        DeptName: '',
        PCode: '',
      },
      form: {
          ReservationDate: '',
          FixedFeeRuleID: '',
          Remark: '',
          MTimeID: ''
      },
      pagesize: 30,
      pageindex: 1,
      loadedAll:false,
      DeptObj: {},
      selections: [],
      openSync: false,
    };
  },
  created() {

  },
  mounted() {
    this.getdata();
  },
  methods: {
    openD() {
      //打开侧边
      this.open = true;
    },
    handleSortChange() {
      console.log(data);
    },
    rowClick(data) {
      console.log(data);
      this.openSimple = true;
      this.rowdata = data;
      [this.rowdata].map(item => {
        console.log(item);
      });
    },
    getdata() {
      let that = this;
      PeosonalPosGetAllPeople({ PageIndex: this.pageindex, PageSize: this.pagesize })
        .then(res => {
          that.list = [...that.list, ...res.RetData];
        })
        .catch(err => {
         
        });
    },
    searchdata(){
      let that = this;
      let param={
          ...this.searchitem
      }
      if (param.PName !== '') {
        param.PName_oper = 'like';
      }
      if (param.DeptName !== '') {
        param.DeptName_oper = 'like';
      }
      if (param.PCode !== '') {
        param.PCode_oper = 'like';
      }
      for (let v in param) {
        if (param[v] === '') {
            delete param[v]
        }
      }
      PeosonalPosGetAllPeople({ PageIndex: this.pageindex, PageSize: this.pagesize,...param})
        .then(res => {
          that.list=[]
          that.list = [...that.list, ...res.RetData];
        })
        .catch(err => {
         
        });
    },
    refresh() {
      this.refreshing = true;
      this.$refs.table_data.scrollTop = 0;
      this.pageindex=1;
      setTimeout(() => {
        this.refreshing = false;
        this.loadedAll=false;
        this.list = [];
        this.getdata();
      }, 2000);
    },
    load() {
      this.loading = true;
      this.pageindex++;
      let a = this.$refs.loadmore.scrollTop;
      this.$refs.loadmore.scrollTop = a;
      let that = this;
      PeosonalPosGetAllPeople({ PageIndex: this.pageindex, PageSize: this.pagesize })
        .then(res => {
          that.list = [...that.list, ...res.RetData];
          setTimeout(() => {
            that.$refs.loadmore.scrollTop = a;
          },800);
          setTimeout(() => {
            that.loading = false;
            that.loading = false;
             if(res.RetData.Data.length==0){
              that.loadedAll=true;
              that.$toast.config({
                position: 'bottom'
              })
              that.$toast.warning('没有更多数据了！！')
            }
          }, 1000);
        })
        .catch(err => {
          // alert(err)
          that.loading = false;
        });
    },
    closeFullscreenDialog() {
        this.openSync = false
    },
    submit() {
      this.searchdata()
    },
    tableSelectChange(item) {
        this.selections = item
    },
    MIMIListSelectChange(item) {
        this.MIMIselections = item
    },
    bookking() {
        if (this.selections.length === 0) {
            this.$toast.warning('请选择需要订餐人员')
            return
        }
        PeosonalPosGetPOSMealTime({
            pageSize: 30,
            pageNumber: 1
        }).then(res => {
            if (res.RetCode === 1) {
                let datetime = (moment(new Date()).format('YYYY-MM-DD'))+' 00:00:00'
                datetime = Date.parse(datetime)
                for (let item of res.RetData) {
                    item.begins = moment(Number(item.BeginTime*60*1000) + datetime).format('YYYY,MM,DD,HH,mm,ss')
                    item.endins = moment(Number(item.EndTime*60*1000) + datetime).format('YYYY,MM,DD,HH,mm,ss')
                    item.BeginTime = moment(Number(item.BeginTime*60*1000) + datetime).format('HH:mm')
                    item.EndTime = moment(Number(item.EndTime*60*1000) + datetime).format('HH:mm')
                }
                // console.log('asfasf', res.RetData)
                for (let item of res.RetData) {
                    item.tiem = item.BeginTime + '-' + item.EndTime
                }
                this.MIMIList = res.RetData
                this.openSync = true
            }
        })
    },
    nextStep() {
        if (this.MIMIselections.length !== 1) {
            this.$toast.warning('请选择一个订餐餐段')
            return
        }
        PeosonalPosGetFixedFeeRule({
            GetFields: '*',
            sortName: 'RuleName'
        }).then(res => {
            if (res.RetCode === 1) {
                this.BoodingList = res.RetData
                this.openSyncInfo = true
                this.form.MTimeID = this.MIMIselections[0].MTimeID
                this.form.FixedFeeRuleID = this.BoodingList[0].FixedFeeRuleID
                this.form.ReservationDate = new Date().setDate(new Date().getDate() + 1) 
            }    
        })
    },
    Book() { // 订餐
    console.log(1111111)
        if (this.form.MTiFixedFeeRuleIDmeID === '') {
            this.$toast.warning('请选择订餐餐段')
            return
        }
        let bDate = moment(this.form.ReservationDate).format('YYYY-MM-DD') + ' ' +this.MIMIselections[0].BeginTime  // 订餐时间
        let td = new Date()
        let tdate = td.getDate()
        td.setDate(tdate + 1)
        let mDate = moment(td).format('YYYY-MM-DD') + ' ' +this.MIMIselections[0].BeginTime    // 最大订餐时间
        console.log('bDate', Date.parse(new Date(bDate)))
        console.log('mDate', Date.parse(new Date(mDate)))
        if (Date.parse(new Date(bDate)) > Date.parse(new Date(mDate))) {    // 如果订餐时间大于最大订餐天数
            this.$toast.warning('订餐时间大于最大订餐天数')
            return
        }
        let nd = new Date()
        let maxDate = moment(nd).format('YYYY-MM-DD') + ' ' +this.MIMIselections[0].EndTime // 此时段最大就餐时间戳
        if (Date.parse(new Date(maxDate)) < Date.parse(new Date())) {
            this.$toast.warning('订餐时间已过')
            return
        }
        let ids = this.selections.map(item => item.pID)
        PeosonalPosReservationInsert({
            IDList: ids.join(','),
            ReservationDate: moment(bDate).format('YYYY-MM-DD HH:mm:ss'),
            FixedFeeRuleID: this.form.FixedFeeRuleID,
            MealTimeID: this.form.MTimeID ,
            Remark: this.form.Remark
        }).then(res => {
            if (res.RetCode === 1) {
                this.$toast.success('订餐成功')
                this.openSyncInfo = false,
                this.openSync = false
                this.form = this.$options.data().form
            }
        }).catch(err => {
            this.$$toast.error(err.Desc)
        })
    }
  },
  watch: {
    open:function(a,b){
      // console.log(a,b);
      if(a==false){
        this.searchitem = this.$options.data().searchitem
      }
    }
  }
};
</script>
<style>
.home {
  height: 100%;
}
.wrap {
  position: relative;
  height: calc(100% - 100px);
  margin-top: 0.1067rem;
  overflow: auto;
}
</style>


