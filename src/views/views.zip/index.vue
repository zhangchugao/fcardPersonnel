<template>
  <div class="home">
    <mu-appbar style="width: 100%;" color="primary">
      <mu-button icon slot="left">
        <!-- <mu-icon value="menu"></mu-icon> -->
      </mu-button>欢迎使用个人系统
      <mu-button v-if="TuiChu" flat slot="right" @click="lgout">
        <!-- <mu-badge content="1" circle color="secondary" flat slot="right" class="right">
        <mu-button icon class="asdf" @click="Inform">
          <mu-icon value="notifications" class="asf"></mu-icon>
        </mu-button>
        </mu-badge>-->
        退出
      </mu-button>
    </mu-appbar>
    <div class="warp">
      <mu-row justify-content="center">
        <div style="width:100px;height:137.5px;overflow:hidden">
          <img style="width:100%" :src="pImage||oimg">
        </div>
      </mu-row>
      <mu-row justify-content="center">欢迎你 {{pName}}</mu-row>
      <!-- <div class="list_ul">
        <div class="warp_tit" >最近出入门记录</div>
        <Table
          :data="list"
          border
          @row-click="rowClick"
          ref="table_data"
          :height='"calc(100% - 1.04rem)"' 
          size='mini'
          style="width: 100%;">
          {{list}}
          <table-column prop="DoorName" label="门名称" width></table-column>
          <table-column align="" prop="DataTime" label="时间" width='160'></table-column>
          <table-column prop="PortNum" label="事件类型" width='80'>
              <template slot-scope="scope">
               
                  {{scope.row.PortNum==1?'入门':'出门'}}
                
              </template>
          </table-column>
        </Table>
      </div>-->
      <div class="desktop_menu">
        <div class="desktop_menu_item" v-for="(item,index) in menu" :key="index">
          <router-link :to="item.path">
            <mu-ripple
              class="mu-ripple-demo demo-2"
              :style="item.style"
              :color="item.color"
              :opacity="0.7"
            >
              <img :src="item.icon" alt />
            </mu-ripple>

            <p>{{$t(item.val)}}</p>
          </router-link>
        </div>
      </div>
    </div>
    <mu-bottom-nav class="nav" :value="value">
      <mu-bottom-nav-item title="个人中心" icon="person_pin" @click.native="toPerson" value="1"></mu-bottom-nav-item>
      <mu-bottom-nav-item title="报表查询" icon="table_chart" @click.native="toReport" value="2"></mu-bottom-nav-item>
    </mu-bottom-nav>

    <mu-dialog
      title="退出"
      width="600"
      max-width="80%"
      :esc-press-close="false"
      :overlay-close="false"
      :open.sync="openAlert"
    >
      你确定要退出登录吗？
      <mu-button slot="actions" flat color="primary" @click="closeAlertDialog">退出</mu-button>
      <mu-button slot="actions" flat color="primary" @click="closeDialog">取消</mu-button>
    </mu-dialog>
  </div>
</template>
<script>
import rebshi from '@/assets/人事.png';
import xiaofei from '@/assets/消费机设置.png';
import kaoqin from '@/assets/考勤.png';
import menjin from '@/assets/门禁.png';
import tinche from '@/assets/停车.png';
import xungen from '@/assets/巡更.png';
import shuikong from '@/assets/无线水控.png';
import diankong from '@/assets/电控.png';
import dianti from '@/assets/电梯.png';
import xitong from '@/assets/系统.png';
import shipin from '@/assets/视频.png';
import fangke from '@/assets/访客.png';
import { Table, TableColumn } from "element-ui";
import {
  RecentAccessRecord,
  ClientLogout,
  Information,
  GetOSSConfig
} from "@/api/getdata";
import oimg from "@/assets/filt.png";
export default {
  name: "index",
  data() {
    return {
      oimg: oimg,
      list: [],
      openAlert: false,
      value: 0,
      pName: "",
      pImage: "",
      TuiChu: true,
      menu:[
            {
                val:'门禁二维码',
                style:"background-image: linear-gradient(-40deg, #27cbde 15%, #97f0fb 100%), linear-gradient(#43daec, #43daec);",
                icon:rebshi,
                color:'#97f0fb',
                path:'/QRCode'
            },
            {
                val:'远程开门',
                style:"background-image: linear-gradient(-40deg,#00baff 0%, #93e2ff 100%), linear-gradient(#00baff, #00baff);",
                icon:menjin,
                color:'#93e2ff',
                path:'/DoorOperation'
            },
            {
                val:'访客授权',
                style:"background-image:linear-gradient(-40deg, #ecab45 0%, #ffd99e 100%), linear-gradient(#ecab45, #ecab45);",
                icon:kaoqin,
                color:'#ffd99e',
                path:'/Visitor'
            },
            {
                val:'订餐消费',
                style:"background-image: linear-gradient(-40deg, #ec7b44 0%, #ffcb7b 100%), linear-gradient(#ec7b44, #ec7b44);",
                icon:xiaofei,
                color:'#ffcb7b',
                path:'/Ordering'
            }
        ],
    };
  },
  components: {
    Table,
    TableColumn
  },
  created() {
    let that = this;
    var ua = navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == "micromessenger") {
      //ios的ua中无miniProgram，但都有MicroMessenger（表示是微信浏览器）
      wx.miniProgram.getEnv(res => {
        if (res.miniprogram) {
          that.TuiChu = false;
        } else {
          that.TuiChu = true;
        }
      });
    } else {
      that.TuiChu = true;
    }
  },

  mounted() {
    let that = this;
    // RecentAccessRecord().then(res=>{
    //   // console.log(res.RetData);
    //   that.list=[...res.RetData.Data];
    //   console.log(that.list)
    // }).catch(err=>{
    //   // alert(err)
    // })
    // Information().then(res=>{
    //   console.log(res)
    // })
    async function getdata() {
      await Information().then(res => {
        console.log(res);
        if (res) {
          that.pName = res.RetData.PName;
          let PImage = res.RetData.PImage;
          if (res.RetData.PImage) {
            // 如果有图片的话
            GetOSSConfig().then(res => {
              if (res.RetCode === 1) {
                let aliConfig = res.RetData;
                let a = PImage.substring(0, 1);
                if (a === "/") {
                  that.pImage = `https://${res.RetData.BuckName}.${
                    res.RetData.EndPoint
                  }${PImage}?${Date.parse(new Date())}`;
                } else {
                  that.pImage = `https://${res.RetData.BuckName}.${
                    res.RetData.EndPoint
                  }/${PImage}?${Date.parse(new Date())}`;
                }
              }
            });
          }
        } else {
          var ua = navigator.userAgent.toLowerCase();
          if (ua.match(/MicroMessenger/i) == "micromessenger") {
            //ios的ua中无miniProgram，但都有MicroMessenger（表示是微信浏览器）
            wx.miniProgram.getEnv(res => {
              if (res.miniprogram) {
                console.log(wx.miniProgram.navigateBack);
                wx.miniProgram.navigateBack({ delta: 1 });
              } else {
              }
            });
          } else {
            console.log(wx.miniProgram.navigateBack);
          }
        }
      });
      await RecentAccessRecord()
        .then(res => {
          // console.log(res.RetData);
          that.list = [...res.RetData.Data];
          // console.log(that.list)
        })
        .catch(err => {
          // alert(err)
        });
    }
    setTimeout(() => {
      getdata();
    }, 1000);
  },
  methods: {
    handleSortChange() {
      console.log(data);
    },
    rowClick(data) {
      console.log(data);
    },
    lgout() {
      this.openAlert = true;
    },
    closeAlertDialog() {
      let that = this;
      var ua = navigator.userAgent.toLowerCase();
      if (ua.match(/MicroMessenger/i) == "micromessenger") {
        //ios的ua中无miniProgram，但都有MicroMessenger（表示是微信浏览器）
        wx.miniProgram.getEnv(res => {
          if (res.miniprogram) {
            console.log(wx.miniProgram.navigateBack);
            wx.miniProgram.navigateBack({ delta: 1 });
          } else {
            ClientLogout().then(res => {
              this.$progress.start();
              setTimeout(() => {
                that.$progress.done();
                that.$router.push({ path: "/home" });
                that.$store.state.transitionName = "slide-left";
              }, 300);
            });
          }
        });
      } else {
        ClientLogout().then(res => {
          this.$progress.start();
          setTimeout(() => {
            that.$progress.done();
            that.$router.push({ path: "/home" });
            that.$store.state.transitionName = "slide-left";
          }, 300);
        });
      }
    },
    closeDialog() {
      this.openAlert = false;
    },
    toPerson() {
      // alert();
      let that = this;

      var ua = navigator.userAgent.toLowerCase();
      if (ua.match(/MicroMessenger/i) == "micromessenger") {
        //ios的ua中无miniProgram，但都有MicroMessenger（表示是微信浏览器）
        wx.miniProgram.getEnv(res => {
          if (res.miniprogram) {
            console.log(wx.miniProgram.navigateBack);
            // wx.miniProgram.navigateBack({delta: 1})
            wx.miniProgram.switchTab({
              url: "/pages/bindCard/index",
              success: function() {
                console.log("success");
              },
              fail: function() {
                console.log("fail");
              },
              complete: function() {
                console.log("complete");
              }
            });
          } else {
            this.$progress.start();
            setTimeout(() => {
              that.$progress.done();
              that.$router.push({ path: "personal" });
              that.$store.state.transitionName = "slide-left";
            }, 300);
          }
        });
      } else {
        this.$progress.start();
        setTimeout(() => {
          that.$progress.done();
          that.$router.push({ path: "personal" });
          that.$store.state.transitionName = "slide-left";
        }, 300);
      }
    },
    toReport() {
      let that = this;
      this.$progress.start();
      setTimeout(() => {
        that.$progress.done();
        that.$router.push({ path: "Report" });
        that.$store.state.transitionName = "slide-left";
      }, 300);
    },
    Inform() {
      //通知
      alert("管理员通知信息");
    },
    $t(e){
      return e
    }
  }
};
</script>
<style lang="scss" scoped>
.home {
  width: 100%;
  height: 100%;
}
.right {
  display: inline;
  .asdf {
    color: #fefedd;
  }
}
.nav {
  position: fixed;
  bottom: 0;
  width: 100%;
}
.warp {
  margin-top: 8px;
  height: calc(100% - 64px);
  min-height: 6.9333rem;
  padding-bottom: 56px;
}
.list_ul {
  height: calc(100% - 155px);
  overflow-y: auto;
  .warp_tit {
    font-size: 0.5333rem;
    font-weight: 600;
    padding: 0.1333rem 0;
  }
  .el-table--mini {
    font-size: 0.32rem;
  }
}
.desktop_menu {
  margin: auto;
  width: 7.64rem;
  margin-top: 0.2667rem;
  .desktop_menu_item {
    a {
      color: #000000;
      text-decoration: none;
    }
  }
}
.desktop_menu {
  // overflow: hidden;
  clear: both;
  .desktop_menu_item {
    // overflow: hidden;
    float: left;
    width: 1.32rem;
    height: 1.8267rem;
    margin: 0.2667rem 0.9067rem;
    position: relative;
    line-height: normal;
    // border:1px solid #fcfc;
    box-sizing: border-box;
    &:nth-child(3n + 1) {
      float: left;
      margin-left: 0;
    }
    &:nth-child(3n + 2) {
      float: auto;
    }
    &:nth-child(3n + 3) {
      float: right;
      margin-right: 0;
    }
    p {
      font-size: 0.2667rem;
      margin-left: -0.1333rem;
      width: 1.6rem;
    }
    img {
      width: 0.9067rem;
      position: absolute;
      top: 0.2rem;
      left: 0.2rem;
    }
    .mu-ripple-demo {
      position: relative;
      width: 1.32rem;
      height: 1.32rem;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-right: 0.2133rem;
      border-radius: 0.3467rem;
      overflow: hidden;
      box-shadow: 0.0267rem 0.032rem 0.13rem 0.01em rgba(0, 0, 0, 0.23);
      &.demo-1 {
        color: #2196f3;
        border: 1px solid #2196f3;
      }
    }
  }
}
</style>
<style lang='scss'>
em.mu-badge-float {
  position: absolute;
  top: 2px;
  right: -1px;
}
.desktop_menu_item{
        .mu-ripple-wrapper{
            overflow: hidden;
            border-radius: 0.3467rem;
        }
    }
</style>


