<template>
  <div class="home">
    <Nav title="远程开门"></Nav>
    <div class="wrap">
      <mu-paper :z-depth="1">
        <mu-list textline="two-line">
            <div v-for="(item,index) in listData" :key="index" style="overflow:hidden;position: relative;">
                <mu-ripple @click="Doorinfo(index)">
                <mu-list-item avatar :ripple="false" button>
                    <mu-list-item-content>
                    <mu-list-item-title>{{item.DoorName||item.DoorSN}}</mu-list-item-title>
                    <mu-list-item-sub-title>
                        {{item.LctnName}}
                    </mu-list-item-sub-title>
                    </mu-list-item-content>
                    <mu-list-item-action>
                    <mu-list-item-after-text>{{item.Online?'在线':'离线'}}</mu-list-item-after-text>
                    <mu-checkbox color="yellow700" v-model="item.Activity" uncheck-icon="star_border" @click.stop='starclick(index)' checked-icon="star"></mu-checkbox>
                    </mu-list-item-action>
                </mu-list-item>
                </mu-ripple>
                <mu-divider></mu-divider>
            </div>
          
        </mu-list>
      </mu-paper>
    </div>

    <mu-drawer :open.sync="open" :docked="false" :right="true" :width='"100%"'>
        <div style="height:calc(100% - 50px)">
            <mu-appbar color="teal">
                <mu-button icon slot="left" @click="open = false">
                <mu-icon value="arrow_back"></mu-icon>
                </mu-button>
                Menus
            </mu-appbar>
            <div class="mu-person-form">
                <mu-form ref="form" :model="form" label-width="80">
                    <mu-form-item label-position="right" label="访客名称:">
                        <mu-text-field disabled  v-model="listDataItem.DoorName"></mu-text-field>
                    </mu-form-item>

                    <mu-form-item label-position="right" label="SN:">
                        <mu-text-field disabled  v-model="listDataItem.DoorSN"></mu-text-field>
                    </mu-form-item>
                    <mu-form-item label-position="right" label="安装位置:">
                        <mu-text-field disabled  v-model="listDataItem.LctnName"></mu-text-field>
                    </mu-form-item>
                    <mu-form-item label-position="right" label="在线状态:">
                        <div>{{listDataItem.Online?'在线':'离线'}}</div>
                    </mu-form-item>
                </mu-form>

                <div style="margin-top:80px">
                    <img @touchstart="gtouchstart()" @touchend="gtouchend()" style="width:150px" :src="DoorOff_on">
                </div>
            </div>
        </div>
        <mu-button @click='open=false'>close</mu-button>
    </mu-drawer>
    <mu-drawer :open.sync="openDoor" :docked="false" :right="true" :width='"100%"'>
        <div style="height:calc(100% - 50px)">
            <mu-appbar color="teal">
                <mu-button icon slot="left" @click="open = false">
                <mu-icon value="arrow_back"></mu-icon>
                </mu-button>
                Menus
            </mu-appbar>
            <div class="mu-person-form">
                <mu-form ref="form" :model="form" label-width="80">
                    <mu-form-item label-position="right" label="访客名称:">
                        <mu-text-field disabled  v-model="listDataItem.DoorName"></mu-text-field>
                    </mu-form-item>

                    <mu-form-item label-position="right" label="SN:">
                        <mu-text-field disabled  v-model="listDataItem.DoorSN"></mu-text-field>
                    </mu-form-item>
                    <mu-form-item label-position="right" label="安装位置:">
                        <mu-text-field disabled  v-model="listDataItem.LctnName"></mu-text-field>
                    </mu-form-item>
                    <mu-form-item label-position="right" label="在线状态:">
                        <div>{{listDataItem.Online?'在线':'离线'}}</div>
                    </mu-form-item>
                </mu-form>

                <div style="margin-top:80px">
                    <img @touchstart="gtouchstart()" @touchend="gtouchend()" style="width:150px" :src="DoorOff_on">
                </div>
            </div>
        </div>
        <mu-button @click='open=false'>close</mu-button>
    </mu-drawer>
  </div>
</template>
<script>
import Nav from "@/components/nav_top";
import off_bg from '@/assets/remotedoor_off_bg.png'
import on_bg from '@/assets/remotedoor_on_bg.png';


import {PersonalDoorGetDoorList,PersonalDoorAsyncOpenDoor} from '@/api/PersonalDoor.js'

export default {
  components: {
    Nav
  },
  data() {
    return {
        open:false,
        DoorOff_on:on_bg,
        form:{},
        star:[],
        listData:[],
        listDataItem:{},
        openDoor:false
    };
  },
  created() {
    PersonalDoorGetDoorList().then(res=>{
      console.log(res);
      if(res.RetData){
        let arrdata = []
        let arr=[];
        let data=res.RetData;
        for (let index = 0; index < data.length; index++) {
          // console.log(data[index].Activity)
          if (data[index].Activity) {
            arrdata.unshift(data[index])
          } else {
            arrdata.push(data[index])
          }
        }
        // arrdata.unshift(ka)
        console.log(arrdata)
        for (let i = 0; i < arrdata.length; i++) {
          if (arrdata[i].Activity) {
            arr.push(true)
          } else {
            arr.push(false)
          }

        }


        this.listData=arrdata ;
      }
    }).catch(err=>{
      console.log(err);
    })
  },
  methods: {
      Doorinfo(e){
          this.open=true;
          console.log(this.listData[e]);
          this.listDataItem=this.listData[e]
      },
      gtouchstart(){
          this.DoorOff_on=off_bg;
          PersonalDoorAsyncOpenDoor({DoorID:this.listDataItem.DoorID}).then(res=>{
            console.log(res);
            if (res.RetCode==1){
              this.$toast.success({
                message: "开门成功",
                position: "top"
              });
            }
            if (res.ErrCode == -2) {
              this.$toast.error({
                message: "无此门权限",
                position: "top"
              });
            }
            if (res.ErrCode == -3) {
              this.$toast.error({
                message: "门已离线，开门失败",
                position: "top"
              });
            }
            if (res.ErrCode == -4) {
              this.$toast.error({
                message: "查询不到此门的IP地址，此门没有在账套服务器绑定",
                position: "top"
              });
            }
          })
      },
      gtouchend(){
          this.DoorOff_on=on_bg;
      },
      starclick(idx){

          this.star[idx] = !this.star[idx];
          // console.log(this.data.star)
          let data = [...this.listData];
          data[idx].Activity = this.star[idx];
          
      }
  }
};
</script>
<style lang="scss" scoped>
.home {
  height: 100%;
  overflow: hidden;
  .wrap {
    height: calc(100% - 1.6rem);
    margin-top: 0.1067rem;
    overflow-y: auto;
    .imgBox {
      width: 100px;
      height: 137.5px;
      overflow: hidden;
      position: relative;
      img {
        width: 100%;
        height: 100%;
      }
      div {
        width: 100%;
        position: absolute;
        bottom: 0px;
        font-size: 0.3rem;
        height: 0.48rem;
        line-height: 0.48rem;
        background-color: rgba(99, 88, 88, 0.63);
        color: #fff;
        font-weight: 600;
      }
    }
  }
}
.mu-person-form {
  width: 100%;
  .mu-form {
    width: 90%;
    div {
      margin-bottom: 0;
    }
  }
}
</style>
<style lang='scss'>
.dialog .mu-dialog .mu-dialog-body {
  height: 100%;
}
</style>
